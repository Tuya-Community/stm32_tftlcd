#ifndef __TYPE_H
#define __TYPE_H 
#include "stm32l476xx.h"
typedef uint32_t  u32;
typedef uint16_t u16;
typedef uint8_t  u8;
typedef int32_t  s32;
typedef int16_t s16;
typedef int8_t  s8;

#endif





























