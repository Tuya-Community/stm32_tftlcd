使用ST的NUCLEO-L476RG开发板，2.8寸ALIENTEK TFTLCD模块；
实现手画板的功能。


Using ST nucleo-L476RG development board, 2.8-inch ALIENTEK TFTLCD module;  
To achieve the function of hand drawing board.  
 